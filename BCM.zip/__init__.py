import bcm

